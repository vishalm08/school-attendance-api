const db = require('../config/db');

exports.createPeriod = async (req, reply) => {
  const { class_id, subject, start_time, end_time, period_number, time } =
    req.body;
  await db.query(
    'insert into periods (class_id, subject, start_time, end_time, period_number, time) VALUES (?, ?, ?, ?, ?, ?)',
    [class_id, subject, start_time, end_time, period_number, time]
  );
  reply.send({ msg: 'Period created' });
};

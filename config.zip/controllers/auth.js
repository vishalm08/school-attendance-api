const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const db = require('../config/db');

exports.login = async (req, reply) => {
  const { username, password } = req.body;
  const [users] = await db.query('select * from users where username = ?', [
    username,
  ]);

  // console.log('Entered Password:', password);
  // console.log('DB Password Hash:', users[0]?.password);

  if (
    users.length === 0 ||
    !(await bcrypt.compare(password, users[0].password))
  ) {
    return reply.code(401).send({ error: 'Invalid credentials' });
  }

  const token = jwt.sign({ id: users[0].id }, process.env.JWT_SECRET, {
    expiresIn: '1d',
  });
  reply.send({ token });
};

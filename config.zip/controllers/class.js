const db = require('../config/db');

exports.createClass = async (req, reply) => {
  const { name } = req.body;
  await db.query('insert into classes (class_name) values (?)', [name]);
  reply.send({ msg: 'Class created' });
};

exports.getClasses = async (req, reply) => {
  const { page = 1, limit = 10 } = req.query;
  const offset = (page - 1) * limit;
  const [rows] = await db.query('select * from classes limit ? offset ?', [
    +limit,
    +offset,
  ]);
  reply.send(rows);
};

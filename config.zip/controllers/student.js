const db = require('../config/db');

exports.createStudent = async (req, reply) => {
  const { name, class_id } = req.body;
  await db.query('insert into students (name, class_id) values (?, ?)', [
    name,
    class_id,
  ]);
  reply.send({ msg: 'Student added' });
};
